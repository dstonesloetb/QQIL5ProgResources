class Multi
{
	public static void main ( String[] args )
	{
		String msg = "This is a local variable in the Multi class";
		System.out.println( msg );

		System.out.println( Data.txt );

		Data.greeting();
	
		Draw.line();	
	}
}


