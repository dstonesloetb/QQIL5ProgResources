public class Test
{
	public static void main( String[] args )
	{
		String text = "success" ;
		System.out.println( "Test " + text ) ;
	}
}
