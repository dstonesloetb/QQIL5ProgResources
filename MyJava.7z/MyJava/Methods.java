class Methods
{
	public static void main ( String[] args )
	{
		System.out.println( "Message from the main method." );
		sub() ;
	}

	public static void sub ( )
	{
		System.out.println( "Message from the sub method." );
	}
}
