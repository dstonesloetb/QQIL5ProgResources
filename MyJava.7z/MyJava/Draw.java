class Draw
{
	static void line()
	{
		System.out.println("___________________________________________");
	}
}
