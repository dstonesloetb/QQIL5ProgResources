class DoWhile
{
	public static void main( String[] args )
	{	
		int num = 100 ;

		do
		{
			System.out.println( "DoWhile Countup: " + num );	
			num += 10;
		}
		while ( num < 10 );		
	}
}
