class Car
{
	public final static String color = "Red" ;
	public final static String bodyType = "Coupe" ;

	public static String accelerate()
	{
		String motion = "Accelerating -->" ;
		return motion;
	}
}


