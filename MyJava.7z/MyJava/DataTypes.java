class DataTypes
{
	public static void main ( String[] args )
	{
		char letter = 'M';
		String title = "Java in easy steps";
		int number = 365;
		float decimal = 98.6f;
		boolean result = true ;

		System.out.println( "Initial is " + letter ) ;		
		System.out.println( "Book is " + title ) ;		
		System.out.println( "Days are " + number ) ;		
		System.out.println( "Temperature is " + decimal ) ;		
		System.out.println( "Answer is " + result ) ;
	}
}
