class Round
{
	public static void main( String[] args )
	{
		float num = 7.25f;

		System.out.println( num + " rounded is " + Math.round(num) );
		System.out.println( num + " floored is " + Math.floor(num) );
		System.out.println( num + " ceiling is " + Math.ceil(num) );
	}
}
