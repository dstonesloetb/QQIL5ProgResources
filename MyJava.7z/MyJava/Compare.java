class Compare
{
	public static void main( String[] args )
	{
		float num1 = 24.75f;
		int num2 = 25;

		System.out.println( "Most is " + Math.max( num1, num2 ) );
		System.out.println( "Least is " + Math.min( num1, num2) );
	}
}
