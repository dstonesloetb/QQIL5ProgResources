class Data
{
	public final static String txt = "This is a global variable of the Data class";

	public static void greeting()
	{
		System.out.print( "This is a global method " );
		System.out.println( "of the Data class" );
	}
}


