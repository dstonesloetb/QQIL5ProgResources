class FirstVariable
{
	public static void main ( String[] args )
	{
		String message = "Initial value" ;
		System.out.println( message ) ;
		message = "Modified value" ;
		System.out.println( message ) ;
	}
}
